// A $( document ).ready() block.
$( document ).ready(function() {
    //alert('test');
  
 
$('.carousel').carousel({
  interval: 2000
});
  
  
  
  
 
  
  

  
});






